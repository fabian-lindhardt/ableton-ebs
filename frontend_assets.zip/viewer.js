// Twitch Extension Helper
const twitch = window.Twitch.ext;
let authToken = 'dev-token'; // Default for local testing without Twitch Rig

// Store Triggers
let activeTriggers = [];

// Add Static Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('btn-start')?.addEventListener('click', () => sendCommand('start'));
    document.getElementById('btn-stop')?.addEventListener('click', () => sendCommand('stop'));
});

// Listen for Config Changes (Load Dynamic Buttons)
twitch.configuration.onChanged(() => {
    console.log('Config Changed Event');
    if (twitch.configuration.broadcaster) {
        try {
            const config = JSON.parse(twitch.configuration.broadcaster.content);
            if (config && config.triggers) {
                console.log('Loading Triggers:', config.triggers);
                activeTriggers = config.triggers;
                renderButtons();
            }
        } catch (e) {
            console.error('Invalid Config JSON');
        }
    } else {
        console.log('No configuration found');
        document.getElementById('dynamic-triggers').innerHTML = '<div class="empty-state">No triggers configured yet. Go to Extension Config!</div>';
    }
});

function renderButtons() {
    const container = document.getElementById('dynamic-triggers');
    if (!container) return; // Should be in panel.html

    container.innerHTML = ''; // Clear old buttons

    activeTriggers.forEach(trigger => {
        // Wrapper for grid cell
        const wrapper = document.createElement('div');
        wrapper.className = 'pad'; // Reuse pad for base size/shape

        // Dynamic Styling
        const color = trigger.color || '#9146FF';

        if (trigger.type === 'fader') {
            // --- FADER LOGIC ---
            wrapper.style.backgroundColor = '#222'; // Darker for UI element
            wrapper.style.cursor = 'default';
            wrapper.style.display = 'flex';
            wrapper.style.flexDirection = 'column';
            wrapper.style.justifyContent = 'center';
            wrapper.style.alignItems = 'center';

            // Allow pointer events on internal elements
            wrapper.style.pointerEvents = 'auto';

            wrapper.innerHTML = `
                <span class="label" style="font-size:0.7em; margin-bottom:5px; pointer-events:none;">${trigger.label}</span>
                <input type="range" min="0" max="127" value="0" class="fader-input" style="width: 80%; accent-color: ${color}; cursor: pointer;">
                ${trigger.cost > 0 ? `<span class="cost">💎 ${trigger.cost}</span>` : ''}
            `;

            container.appendChild(wrapper);

            const input = wrapper.querySelector('input');

            // Throttled Sender to prevent rate limits
            const sendThrottled = throttle((val) => {
                // Clone trigger to send dynamic value
                const dynamicTrigger = { ...trigger, value: parseInt(val) };
                // Currently ignoring cost for movement, treating as 'access granted'
                sendSmartTrigger(dynamicTrigger);
            }, 100); // 100ms throttle

            input.addEventListener('input', (e) => {
                sendThrottled(e.target.value);
            });

            // Prevent clicking the wrapper from triggering anything else
            input.addEventListener('click', (e) => e.stopPropagation());

        } else {
            // --- BUTTON LOGIC ---
            wrapper.style.backgroundColor = color;
            wrapper.style.boxShadow = `0 0 5px ${color}`;
            wrapper.style.cursor = 'pointer';

            wrapper.innerHTML = `
                <span class="label">${trigger.label}</span>
                ${trigger.cost > 0 ? `<span class="cost">💎 ${trigger.cost}</span>` : ''}
            `;

            wrapper.addEventListener('click', () => {
                // Visual Flash Animation
                wrapper.style.boxShadow = `0 0 20px ${color}, inset 0 0 10px white`;
                wrapper.style.filter = 'brightness(1.5)';
                setTimeout(() => {
                    wrapper.style.boxShadow = `0 0 5px ${color}`;
                    wrapper.style.filter = 'brightness(1.0)';
                }, 150);

                sendSmartTrigger(trigger);
            });

            container.appendChild(wrapper);
        }
    });
}

// Helper: Throttle
function throttle(func, limit) {
    let lastFunc;
    let lastRan;
    return function () {
        const context = this;
        const args = arguments;
        if (!lastRan) {
            func.apply(context, args);
            lastRan = Date.now();
        } else {
            clearTimeout(lastFunc);
            lastFunc = setTimeout(function () {
                if ((Date.now() - lastRan) >= limit) {
                    func.apply(context, args);
                    lastRan = Date.now();
                }
            }, limit - (Date.now() - lastRan));
        }
    }
}


// Keep the localhost URL for now, but in production this should be relative or configured
const EBS_API = 'https://abletonlivechat.flairtec.de/api/trigger';

async function sendCommand(type) {
    updateStatus('Transport: ' + type);
    const payload = {
        action: type,
        midi: { action: type }
    };
    await sendEBS(payload);
}

async function sendSmartTrigger(trigger) {
    // Only show status updates for non-fader triggers to avoid log spam
    if (trigger.type !== 'fader') {
        updateStatus(`Sending: ${trigger.label}...`);
    }

    // Construct specific MIDI payload based on type
    // This cleaning ensures logs are readable and correct
    let midiData = {
        action: trigger.type,
        channel: trigger.channel || 0, // Use Configured Channel
        value: trigger.value
    };

    if (trigger.type === 'noteon' || trigger.type === 'noteoff') {
        midiData.note = trigger.value;       // Note Number
        midiData.velocity = trigger.velocity;
    } else if (trigger.type === 'cc' || trigger.type === 'fader') {
        midiData.controller = trigger.controller; // CC Number
        midiData.value = trigger.value;          // CC Value
        // 'note' is undefined here, removing ambiguity
    }

    const payload = {
        action: 'trigger',
        midi: midiData
    };

    await sendEBS(payload);
}

async function sendEBS(payload) {
    try {
        const res = await fetch(EBS_API, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(payload)
        });

        const data = await res.json();
        // Silent success for faders
        if (data.success) {
            if (payload.midi.action !== 'fader') {
                updateStatus('Sent!');
                setTimeout(() => updateStatus('Ready'), 2000);
            }
        } else {
            updateStatus('Error: ' + data.message);
        }

    } catch (err) {
        console.error(err);
        updateStatus('Failed to connect to EBS');
    }
}

function updateStatus(msg) {
    const el = document.getElementById('status');
    if (el) el.innerText = msg;
}

// Listen for the onAuthorized event to get the JWT
if (twitch) {
    twitch.onAuthorized((auth) => {
        console.log('Twitch Authorized:', auth);
        authToken = auth.token;
        updateStatus('Connected to Twitch!');
    });
}
